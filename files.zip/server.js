const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'votes.json');

// ── Middleware ──────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── DB helpers ──────────────────────────────────────────────────────────────
function readVotes() {
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify([]));
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch { return []; }
}

function writeVotes(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ── Poll config (edit question & options here) ───────────────────────────────
const POLL = {
  question: "Which technology are you most excited about in 2025?",
  options: [
    { id: "a", label: "Artificial Intelligence & LLMs" },
    { id: "b", label: "Quantum Computing" },
    { id: "c", label: "Augmented Reality (AR/XR)" },
    { id: "d", label: "Biotech & Gene Editing" },
  ]
};

// ── Routes ───────────────────────────────────────────────────────────────────

// GET /api/poll — return question and options
app.get('/api/poll', (req, res) => {
  res.json(POLL);
});

// POST /api/vote — submit a vote
app.post('/api/vote', (req, res) => {
  const { name, choice } = req.body;

  if (!name || typeof name !== 'string' || name.trim().length === 0)
    return res.status(400).json({ error: 'Name is required.' });

  const validIds = POLL.options.map(o => o.id);
  if (!choice || !validIds.includes(choice))
    return res.status(400).json({ error: 'Invalid choice.' });

  const votes = readVotes();
  const trimmedName = name.trim();

  const existing = votes.find(v => v.name.toLowerCase() === trimmedName.toLowerCase());
  if (existing)
    return res.status(409).json({ error: 'You have already voted.' });

  const option = POLL.options.find(o => o.id === choice);
  const entry = {
    id: Date.now(),
    name: trimmedName,
    choice,
    choiceLabel: option.label,
    votedAt: new Date().toISOString()
  };

  votes.push(entry);
  writeVotes(votes);

  res.json({ success: true, entry });
});

// GET /api/results — return all votes (for admin)
app.get('/api/results', (req, res) => {
  const votes = readVotes();

  // Tally counts per option
  const tally = {};
  POLL.options.forEach(o => tally[o.id] = { label: o.label, count: 0 });
  votes.forEach(v => { if (tally[v.choice]) tally[v.choice].count++; });

  res.json({
    total: votes.length,
    tally: Object.values(tally),
    votes: votes.sort((a, b) => new Date(b.votedAt) - new Date(a.votedAt))
  });
});

// GET /results — serve the admin results page
app.get('/results', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'results.html'));
});

// Fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🗳️  Polling server running at http://localhost:${PORT}`);
  console.log(`📊  Results page:         http://localhost:${PORT}/results\n`);
});
